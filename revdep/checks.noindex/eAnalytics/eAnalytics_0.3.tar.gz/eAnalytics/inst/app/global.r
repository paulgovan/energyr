# global.R template for Plotly/Shiny apps

library(plotly)
library(shiny)

source("plotlyGraphWidget.r")
