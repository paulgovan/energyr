# eAnalytics 0.3

# eAnalytics 0.2

## Minor improvements and bug fixes

* `eAnalytics()` now has the same UI locally as on shinyapps.io.

# eAnalytics 0.1.4

## Major Changes

* Added tests 

## Minor Changes

* Added orcid
